# Kaine Zhu 朱璽

![朱璽 Kaine Zhu](assets/portrait.jpg)

AI Applications · Product Development · EdTech

- **AI application delivery:** Combines machine learning research with AI development, taking products from requirements and UI/UX through system integration, release and real-world use.
- **AI / AI agent adoption:** Drives AI adoption and digital workflows at Kang Chiao International School, using AI agents in product development and translating practical methods into training and reusable workflows.
- **Ongoing research collaboration:** Works with NTU’s Department of Bioenvironmental Systems Engineering on research and related projects exploring LLM and NLP applications in ESG sustainability data, sustainable buildings, energy systems and power grids.

---

- ✉️ [ryanzhu@kainnne.com](mailto:ryanzhu@kainnne.com)
- 🌐 [kainnne.com](https://kainnne.com)
- 💻 [github.com/kainnne](https://github.com/kainnne)

## Experience

### Kang Hsuan Educational Publishing Group / Kang Chiao International School

AI Engineer / Digital Learning Engineer | Jul 2026 - Present

- Drives school-wide AI applications and digital workflows, bringing AI adoption into practice.
- Delivered staff training on August 19, 25 and 28, 2026, and designed session plans, presentations, guides and exercises around participants’ experience levels.
- Uses AI tools to produce instructional videos efficiently while maintaining content quality, clear teaching and a personal style for teachers and administrative staff.

### National Taiwan University

Bioenvironmental Systems Engineering\
Research Assistant\
Sep - Dec 2025, Aug 2026 - Present

Developed the model architecture and Python implementation of a real-time flood early-warning system. Packaged models and designed data transmission workflows to support partner integration with government web platforms.

Tracked project progress and coordinated requirements with government agencies and technology partners. Continues research collaboration and related projects on LLM and NLP applications in ESG sustainability data, sustainable buildings, energy systems and power grids.

### National Sun Yat-sen University

Marine Environment and Engineering\
Research Assistant | Jan 2026

Analyzed data patterns and feature relationships to inform predictive model improvements and research design.

## Selected Recent Work

### LumaReader

Personal product | Markdown reading, editing & PDF export

- Developed a local-first Markdown app with folder libraries, Mermaid, KaTeX, media previews, themes and interface languages.
- Refined source/preview editing, undo/redo and PDF export with page breaks, optional footers and frames.
- Released v1.3.1 for macOS, Windows and Linux alongside a web edition, bringing the product into real customer use and continuing to improve the reading experience.

[lumareader.kainnne.com](https://lumareader.kainnne.com)

## Additional Projects

### WikiNB

Personal edition | Markdown knowledge base & digital twin

- Integrated sign-in, note synchronization and full-text browsing to organize Markdown notes into a maintainable knowledge system.
- Built a personal project assistant and digital twin, offering a simple Q&A entry point for visitors to learn about my experience and work, start conversations or explore collaboration.

[wikinb.kainnne.com](https://wikinb.kainnne.com)

### AI Tools

Free tools | From everyday ideas to useful applications

- Quickly turns everyday ideas into small, free tools, exploring uses that could solve practical problems.
- Developed Taiwan Car Finder and other tools and gathered them in the AI Tools hub for people to try, with ongoing improvements.

[ai-tools.kainnne.com](https://ai-tools.kainnne.com)

## Core Capabilities

- **AI & Systems** — Python, LLM applications, data processing and feature engineering, automation

- **Product & Interface** — UI/UX, full-stack applications, product delivery experience

- **Research & Analysis** — Machine learning, structural engineering, time-series prediction, model validation, machine learning competition experience

- **AI / AI Agent Adoption** — Training, learning materials, cross-team requirements communication

## Education

### National Sun Yat-sen University

M.S., Marine Environment and Engineering\
2023 - 2025

### National Sun Yat-sen University

B.S., Marine Environment and Engineering\
2019 - 2023

### Master’s Thesis

Structural Engineering × Machine Learning

Used LS-DYNA simulation data to predict maximum and permanent deflections of corrugated blast walls under explosion loads. Conducted preprocessing, feature engineering, model tuning and validation, and feature importance analysis.

[Read the thesis — Prediction of Deflections on Corrugated Blast Wall under Explosion Loads Using Machine Learning](https://ethesys.lis.nsysu.edu.tw/eThesys-dbs/ETD-search/view_etd.php?urn=etd-0723125-151645)

## Creative Work & Leadership

Former chamber music club president with experience in concert planning and production, composition, conducting and instrumental performance.

Released the original album [Everything Before 24](https://music.youtube.com/playlist?list=OLAK5uy_mnNVxpjDw5dwcnLaquhOUxn_S_Jn6a46Q) in 2026 and continues working on music and writing.
