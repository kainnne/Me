# 朱璽 Kaine Zhu

![朱璽 Kaine Zhu](assets/portrait.jpg)

AI 應用開發｜產品設計｜教育科技

- **AI 應用落地**：結合機器學習研究與 AI 應用開發，具備從需求定義、UI／UX、系統整合到產品發布與實際使用的完整實作經驗。
- **AI／AI Agent 導入**：現於康橋國際學校推動 AI 導入與數位工作流程，運用 AI Agent 協作開發產品，並將實務方法轉化為教育訓練與可重複使用的工作流程。
- **持續研究合作**：持續與臺大生物環境系統工程學系進行研究合作及相關計畫，聚焦 LLM、NLP 在 ESG 永續數據、永續建築與能源電網上的應用。

---

- ✉️ [ryanzhu@kainnne.com](mailto:ryanzhu@kainnne.com)
- 🌐 [kainnne.com](https://kainnne.com)
- 💻 [github.com/kainnne](https://github.com/kainnne)

## 工作經歷

### 康軒文教集團／康橋國際學校

AI 工程師／數位教學工程師｜2026.07 - 至今

- 推動校內 AI 應用與數位工作流程，完成 AI 導入。
- 完成 2026 年 8 月 19 日、25 日、28 日的教職員教育訓練，並依同仁使用程度設計課程流程、簡報、教學文件與實作範例。
- 運用 AI 工具高效率製作教學影片，兼顧內容品質、清楚的教學表達與個人風格，支援教師與行政同仁學習。

### 國立臺灣大學

生物環境系統工程學系\
研究助理｜2025.09 - 2025.12、2026.08 - 至今

以 Python 開發即時淹水預警系統的模型架構與程式，封裝模型並設計資料傳輸流程，支援合作廠商介接政府公共網站平台。

追蹤專案進度，與政府機關及外部技術公司溝通需求與進度。目前持續參與 LLM、NLP 於 ESG 永續數據、永續建築與能源電網應用的研究合作及相關計畫。

### 國立中山大學

海洋環境及工程學系\
研究助理｜2026.01

分析資料模式與特徵關係，作為預測模型優化與研究設計的參考。

## 近期代表成果

### 客製化 AI 文件處理平台

客戶委託｜UI／UX、AI Agent 與本機整合

- **3 天業餘時間**完成初版設計。
- **7 分鐘簡報**取得客戶委託。
- 依預算與本機需求，設計並交付**網頁平台**。
- 完成**百筆內容批次測試**，確認輸出完整、順序正確。

> **技術設計**：文件分段、受控 Agent 平行處理、結果保存與失敗續跑，輸出 Markdown。

可於面試提供操作示範。

### LumaReader

個人產品開發｜Markdown 閱讀、編輯與 PDF 匯出

- 開發本機優先的 Markdown 應用，整合資料夾文件庫、Mermaid、KaTeX 與媒體預覽，並設計多主題、多語介面。
- 迭代原文／預覽對照、編輯復原與重做，以及分頁、頁尾和外框可調整的 PDF 匯出，處理閱讀與編輯流程中的細節問題。
- 完成 v1.3.1 發布，提供 macOS、Windows 與 Linux 版本及網頁入口，同時將產品落地為已有客戶實際使用的 App，持續改善閱讀體驗。

[lumareader.kainnne.com](https://lumareader.kainnne.com)

## 其他作品

### WikiNB

個人版｜Markdown 知識庫與數位分身

- 整合登入、筆記同步與全文瀏覽，將 Markdown 筆記組織為可持續維護的知識系統。
- 建立個人專案助理與數位分身，讓訪客透過簡易問答認識我的經歷與作品，作為交流或合作的入口。

[wikinb.kainnne.com](https://wikinb.kainnne.com)

### AI Tools

免費小工具｜從日常靈感到實用應用

- 將日常想到的點子快速做成免費小工具，探索能解決實際問題的使用情境。
- 開發台灣選車網等工具，集中於 AI Tools 入口，讓使用者直接體驗並持續改善。

[ai-tools.kainnne.com](https://ai-tools.kainnne.com)

## 核心能力

- **AI 應用與系統** — Python、LLM 應用、資料處理與特徵工程、自動化

- **產品與介面** — UI／UX、全端應用、產品落地經驗

- **研究與分析** — 機器學習、結構工程、時間序列預測、模型驗證、機器學習競賽經驗

- **AI／AI Agent 導入** — 教育訓練、教材設計、跨單位需求溝通

## 學歷

### 國立中山大學

海洋環境及工程學系 碩士\
2023 - 2025

### 國立中山大學

海洋環境及工程學系 學士\
2019 - 2023

### 碩士論文

結構工程 × 機器學習

Used LS-DYNA simulation data to predict maximum and permanent deflections of corrugated blast walls under explosion loads. Conducted preprocessing, feature engineering, model tuning and validation, and feature importance analysis.

[閱讀碩士論文｜Prediction of Deflections on Corrugated Blast Wall under Explosion Loads Using Machine Learning](https://ethesys.lis.nsysu.edu.tw/eThesys-dbs/ETD-search/view_etd.php?urn=etd-0723125-151645)

## 跨領域創作與領導

曾任室內樂社社長，參與音樂會規劃與製作，具作曲、指揮及器樂演出經驗。

2026 年推出個人原創音樂專輯《[Everything Before 24](https://music.youtube.com/playlist?list=OLAK5uy_mnNVxpjDw5dwcnLaquhOUxn_S_Jn6a46Q)》，持續進行音樂與文字創作。
